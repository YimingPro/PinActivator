import com.github.tomakehurst.wiremock.WireMockServer;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

public class PinActivatorTest {
    private WireMockServer wireMockServer;

    @Before
    public void setup() {
        wireMockServer = new WireMockServer(8080);
        wireMockServer.start();
        configureFor("localhost", 8080);

        stubFor(post(urlEqualTo("/activate"))
                .withRequestBody(containing("\"customerId\":\"12345\""))
                .withRequestBody(containing("\"macAddress\":\"AA:BB:CC:DD:EE:FF\""))
                .willReturn(aResponse()
                        .withStatus(201)
                        .withBody("Terminal activated")));

        stubFor(post(urlEqualTo("/activate"))
                .withRequestBody(containing("\"customerId\":\"12345\""))
                .withRequestBody(containing("\"macAddress\":\"AA:BB:CC:DD:EE:AA\""))
                .willReturn(aResponse()
                        .withStatus(404)
                        .withBody("Terminal not registered")));

        stubFor(post(urlEqualTo("/activate"))
                .withRequestBody(containing("\"customerId\":\"11111\""))
                .withRequestBody(containing("\"macAddress\":\"AA:BB:CC:DD:EE:FF\""))
                .willReturn(aResponse()
                        .withStatus(409)
                        .withBody("Terminal already activated")));
    }

    @After
    public void teardown() {
        wireMockServer.stop();
    }

    @Test
    public void testActivatePinTerminal() {
        PinActivator.activatePinTerminal("12345", "AA:BB:CC:DD:EE:FF");

    }

    @Test
    public void testActivateTerminalNotFound() {
        PinActivator.activatePinTerminal("12345", "AA:BB:CC:DD:EE:AA");

    }

    @Test
    public void testActivateTerminalConflict() {
        PinActivator.activatePinTerminal("11111", "AA:BB:CC:DD:EE:FF");

    }
}
