import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class PinActivator {
    private static final Logger logger = LoggerFactory.getLogger(PinActivator.class);
    private static final String URL = "http://localhost:8080/activate";

    public static void activatePinTerminal(String customerId, String macAddress) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost postRequest = new HttpPost(URL);
            String jsonPayload = String.format("{\"customerId\":\"%s\", \"macAddress\":\"%s\"}", customerId, macAddress);
            postRequest.setEntity(new StringEntity(jsonPayload));
            postRequest.setHeader("Content-type", "application/json");

            try (CloseableHttpResponse response = httpClient.execute(postRequest)) {
                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());

                switch (statusCode) {
                    case 201:
                        logger.info("ACTIVE: " + responseBody);
                        sendStatusToOrchestrator("ACTIVE");
                        break;
                    case 404:
                        logger.error("INACTIVE: Not Found - " + responseBody);
                        sendStatusToOrchestrator("INACTIVE");
                        break;
                    case 409:
                        logger.error("INACTIVE: Conflict - " + responseBody);
                        sendStatusToOrchestrator("INACTIVE");
                        break;
                    default:
                        logger.error("Unexpected response: " + responseBody);
                        sendStatusToOrchestrator("ERROR");
                }
            }
        } catch (Exception e) {
            logger.error("Failed to send request", e);
        }
    }

    private static void sendStatusToOrchestrator(String status) {

        logger.info("Sending status to orchestrator: " + status);
    }

    public static void main(String[] args) {
        activatePinTerminal("12345", "AA:BB:CC:DD:EE:FF");
    }
}
